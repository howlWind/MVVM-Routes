//
//  AppDelegate+ViewModel.h
//  MVVM+Routes
//
//  Created by yihua on 2018/11/1.
//  Copyright © 2018年 yihua. All rights reserved.
//

#import "AppDelegate.h"
#import "GJ-prefix-header.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (ViewModel)

- (void)registerNavgationRouter;

@end

NS_ASSUME_NONNULL_END
