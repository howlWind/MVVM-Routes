//
//  AppDelegate.h
//  MVVM+Routes
//
//  Created by yihua on 2018/11/1.
//  Copyright © 2018年 yihua. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

